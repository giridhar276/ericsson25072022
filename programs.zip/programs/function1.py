

def add(a,b):
    c = a + b
    return c




print(add(10,20))

total = add(10,20)
print(total)