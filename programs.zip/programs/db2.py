

import pymysql
import sys
import getpass       



try:
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='ericsson')

    

    conn.close()
except Exception as err:
    print(err)
    print(sys.exc_info())

    
    
    
    
    
    
    