


ytag = {
  "kind": "youtube#searchListResponse",
  "etag": "111m2yskBQFythfE4irbTIeOgYYfBU",
  "nextPageToken": "CAUQAA",
  "regionCode": "KE",
  "pageInfo": {
    "totalResults": 4249,
    "resultsPerPage": 5
  },
  "items": [
    {
      "kind": "youtube#searchResult",
      "etag": "222m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#channel",
        "channelId": "UCJowOS1R0FnhipXVqEnYU1A"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "333m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#video",
        "videoId": "Eqa2nAAhHN0"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "444m2yskBQFythfE4irbTIeOgYYfB",
      "id": {
        "kind": "youtube#video",
        "videoId": "IirngItQuVs"
      }
    }
  ]
}


for key,value in ytag.items():
    if key == "etag" and isinstance(value,str):
        print(ytag['etag'])
    elif isinstance(value,list):
        for item in value :
            if 'etag' in item:
                print(item['etag'])
    
