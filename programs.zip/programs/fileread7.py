

'''
Write a Python program to read realestate.csv and display all the lines satisfying the below

– type should be residential

– price shouldbe greater than 100000

– city should be either SACRAMENTO or RIO LINDA
'''


import csv
with open("realestate.csv","r") as fobj:
    #converting convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        if line[7] == 'Residential' and int(line[9]) > 100000 and line[1] in ['SACRAMENTO','RIO LINDA']:
            print(line)
        
        
        
## anaconda  comes with python


## python first ( www.python.org) and then install pycharm


## microsoft visual studio code ( instlal the extension of python)
