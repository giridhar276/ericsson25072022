

import pymysql
import sys
import getpass       

try:
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='ericsson')
    # creating cursor in order to navigate
    cursor = conn.cursor()
    # step2
    query = "create table realestate2 ( street varchar(100), city varchar(200))"
    #step3
    cursor.execute(query)

    query = "insert into realestate values('{}','{}')".format('ABCRoad','Mumbai')
    #step3
    cursor.execute(query)
    
    print(cursor.rowcount,"row inserted")
    
    conn.close()
except pymysql.err.IntegrityError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print("Invalid credentials ",err)
except pymysql.err.InterfaceError as err:
    print(err)
except Exception as err:
    print(err)
    print(sys.exc_info())

    
    
    
    
    