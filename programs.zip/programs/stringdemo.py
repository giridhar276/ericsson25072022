
name = "python programming"
print(name)
print("I love",name)

print(name[0])
print(name[1])
print(name[2])
# string[start:stop:step]  # string slicing
print(name[0:5])
print(name[2:8])
print(name[7:9])
print(name[0:18:1])
print(name[0:18])
print(name[0:18:2])
print(name[1:18:2])
print(name[2:18:3])
print(name[-1])  #g
print(name[-2])
print(name[-5:-2])
print(name[::])     # python programming
print(name[::-1])   # reverse the string
print(name[5:2:-1])




# range(start,stop,step)
for val in range(1,11):
    print(val)

for val in range(1,11,2):
    print(val)

for val in range(1,11,3):
    print(val)
    
for val in range(2,11,2):
    print(val)    

for val in range(10,2,-2):
    print(val)


name = "python"
for char in name:
    print(char)

alist  = [10,20,30]
for val in alist:
    print(val)























