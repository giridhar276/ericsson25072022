
# read operation
# displaying the content line by line
# using context manager
# fobj acts like an cursor or pointer or reference
with open("realestate.csv","r") as fobj:
    for line in fobj:
        print(line.strip())
        
        
        
with open("realestate.csv","r") as fobj:
    for line in fobj:
        if 'SACRAMENTO' in line:
            print(line.strip())        
            
        
with open("realestate.csv","r") as fobj:
    for line in fobj:
        getcount = line.count('SACRAMENTO')
        if getcount > 0:
            print(line.strip())               
            
            
            
with open("realestate.csv","r") as fobj:
    for line in fobj:
        output = line.split(",")
        print(output)
        if output[1] == 'SACRAMENTO':
            print(line.strip())                           