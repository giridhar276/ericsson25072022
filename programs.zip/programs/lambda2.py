
# write a program to the  list and diplay the below output

# 1st method
alist = ["google","oracle","microsoft"]
blist =[]

for item in alist:
    blist.append("www." + item + ".com")
print(blist)


# 2nd method
alist = ["google", "oracle", "microsoft"]

url = lambda l : ["www."+x+".com" for x in l]

print(url(alist))



# 3rd method using map()
alist = ["google","oracle","microsoft"]

append = lambda x : "www." + x + ".com"
print(list(map(append,alist)))





# 3rd method using map()
alist = ["google","oracle","microsoft"]
print(list(map(lambda x : "www." + x + ".com",alist)))


# 4th method
def increment(x):
    return  "www." + x + ".com"

# 3rd method using map()
alist = ["google","oracle","microsoft"]
print(list(map(increment,alist)))








