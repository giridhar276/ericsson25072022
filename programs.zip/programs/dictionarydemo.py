book = {"chap1":10 , "chap2": 20 ,"chap3":30}
print(book)
## add new key-value
book["chap4"] = 40
book["chap5"] = 50
print("after adding new key values :", book)

# access individual value
print(book)  # display everything
print(book["chap1"])  # 10
print(book["chap2"])  # 20

# only keys
print(book.keys())
print(list(book.keys()))
print(tuple(book.keys()))

# values only
print(book.values())

# display key and value
# list of tuples
print(book.items())

newbook = {"chap8":80 ,"chap9":90}
# combine both the books
book.update(newbook)  #all the items of newbook will be copied to book

# creating new dictionary
finalbook = {**book,**newbook}  # combining both the dictionaries
print(finalbook)






book = {'chap1': 10, 'chap2': 20, 'chap3': 30, 'chap4': 40, 'chap5': 50}

# display the keys
for key in book.keys():
    print(key)
#or
for key in book:
    print(key)

# values
for value in book.values():
    print(value)


# dissplay key:value at a time
for key,value in book.items():
    print(key,value)
    
    
# check for existence of the key
if "chap1" in book:
    print(book["chap1"])
else:
    print("chap1 doesn't exist")
















