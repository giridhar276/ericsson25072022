import pymysql
import sys
import getpass       
import csv
import os

class RealEstate:
    def __init__(self,host,port,user,password,database):
        self.host = host
        self.port  = port
        self.user = user
        self.password = password
        self.database = database
        
    def createConnection(self):
        self.conn = pymysql.connect(host = self.host,port = self.port,user = self.user,password = self.password,database= self.database)
        print(self.conn)
    def displayRecords(self):
        self.cursor = self.conn.cursor()
        self.query = "select * from realestate"
        self.cursor.execute(self.query)
        for record in self.cursor.fetchall():
            print(record)
        
    def closeConnection(self):
        self.conn.close()
                
obj1 = RealEstate('127.0.0.1',3306,'root','india@123','ericsson')
obj1.createConnection()
obj1.displayRecords()
obj1.closeConnection()

print(obj1.host)


