# file gets created in the current directory
fw  = open("languages.txt","w")
fw.write("python\n")
fw.write("unix\n")
fw.write("spark\n")
fw.close()



#fw  = open(r"D:\new\new\languages.txt","w")  # r -raw string
#fw  = open("D:/new/new/languages.txt","w")
fw  = open("D:\\new\\new\\languages.txt","w")
fw.write("python\n")
fw.write("unix\n")
fw.write("spark\n")
fw.close()



# writing numbers to the file
fw  = open("numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")
fw.close()