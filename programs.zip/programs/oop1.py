

# every class contains data members and member funtions(methods)
class Employee:
    def displayEmployee(self,name,addr):
        # initializing values
        self.name = name
        self.addr = addr
    def displayAddress(self):
        print("Name   :", self.name)
        print("Address:", self.addr)


# object creation  or object initialization
emp1 = Employee()
emp1.displayEmployee('Ram','Hyd')
emp1.displayAddress()



emp2 = Employee()
emp2.displayEmployee('Rita','US')
emp2.displayAddress()


emp3 = Employee()
emp3.displayEmployee('Sita','Bang')
emp3.displayAddress()