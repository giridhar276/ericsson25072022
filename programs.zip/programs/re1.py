




with open("languages.txt") as fobj:
    for line in fobj:
        if 'python' in line or 'pyttttthon' in line or 'pyttthon' in line:
            print(line.strip())
            
            
            
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt*hon',line):
            print(line.strip())
            
            
############################            
# starting with python  - ^
############################
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('^python',line):
            print(line.strip())            
            
            
############################            
# ending with python  - $
############################            
            
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('python$',line):
            print(line.strip())            
                   
            
############################     
# * :   zero or more occurences of the preceding character
############################             
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt*hon',line):
            print(line.strip())   
            
            
            
############################  
# + :one or more occurences of the preceding character
############################  
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt+hon',line):
            print(line.strip())              
            
            
#############################   
#? :  either zero or one occurence of the preceding character            
############################    
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt?hon',line):
            print(line.strip())      
            
            
            
#############################   
#? : (pattern1|pattern2) : display lines containing either pattern1 or pattern2         
############################    
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('python|java|unix',line):
            print(line.strip())      
            
            
     
#############################   
#[mqey]: one single character from the given characters         
############################ 
   
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('[pmyqw]ython',line):
            print(line.strip())    

         
#############################   
#{min,max} :   min to max occurences of the preceding characters    
############################

   
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt{2,5}hon',line):
            print(line.strip())    



import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt{2,}hon',line):   # mininum :2 max can be anything
            print(line.strip())   





import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search('pyt{3}hon',line):
            print(line.strip())   














