

try:
    with open("realestate1.csv","r") as fobj:
        for line in fobj:
            if 'SACRAMENTO' in line:
                print(line.strip())

except TypeError as err:
    print("Invalid operation :",err)
except IndexError as err:
    print("Invlaid index :",err)
except FileNotFoundError as error:
    print("File is not found :",error)
except (KeyError,ValueError) as err:
    print("Invalid Key or value :",err)
except Exception as err:
    print(err)    
else:
    with open("languages.txt") as fobj:
        for line in fobj:
            print(line)
        
print("this is the regular program")    
    