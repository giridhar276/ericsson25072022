
import os
#print(os.listdir())

for file in os.listdir():
    print(file)




# display only csv files
for file in os.listdir():
    if file.endswith(".csv"):
        print(file)