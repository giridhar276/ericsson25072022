


import csv
with open("realestate.csv","r") as fobj:
    #converting convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)