

# traditional way #regular way
fw  = open("languages.txt","w")
fw.write("python\n")
fw.write("unix\n")
fw.write("spark\n")
fw.close()

# phthonic way # latest approach
# context manager
# if any line starts with keyword with... we call it as context manager
# Advantage : file gets closed automatically when moving out of indentation
with open("languages.txt","w") as fw:
    fw.write("python\n")
    fw.write("unix\n")
    fw.write("spark\n")
    

