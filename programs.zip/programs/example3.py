'''
Define some list as below

alist = ["google","oracle","microsoft"]

Output:

Output:
http://www.google.com
http://www/.oracle.com
http://www.microsoft.com
'''


alist = ["google","oracle","microsoft"]

for value in alist:
    print("http://www." + value + ".com")