
'''
Write a Python program to capture filename  and display the type of the file

if the filename is ending with .py …. display “Its python file”
if the filename is ending with .pl …. display “Its perl file”
If the filename is ending with .c … display “Its C lang file”
if the filename is ending with .json … display “Its json file”
'''

filename = "example.c"
if filename.endswith(".c"):
    print('its c file')
elif filename.endswith('.pl'):
    print("perl file")