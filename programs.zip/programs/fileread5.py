

import csv
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    alist = []
    countCities = 0
    for line in reader:
        if line[1] in alist:
            continue
        else:
            alist.append(line[1])
            countCities += 1
        #print(line[0].ljust(20),line[1])
    for i in alist:
        print(i)
    print('Total no of cities:',countCities)
    
    
    
import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        cityset.add(line[1])
    for  city in cityset:
        print(city)
    print("Totla no. of cities :", len(cityset))
    
    
    
    



import csv
citylist = list()
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        citylist.append(line[1])
    for  city in set(citylist):
        print(city.ljust(20),citylist.count(city),"times")

        