import pymysql
import sys
import getpass       
import csv
import os
try:
    #step1
    count = 0
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='ericsson')
    # creating cursor in order to navigate
    cursor = conn.cursor()
    # step2
    filename = "realestate.csv"
    if os.path.isfile(filename) and os.path.getsize(filename) > 0:
        with open(filename,"r") as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                query = "insert into realestate values('{}','{}')".format(line[0],line[1])
                #step3
                cursor.execute(query)
                count = count + 1
                
        print(count,"records inserted")
        
        conn.commit()
    else:
        print("file doesn't exist")
    conn.close()
except pymysql.err.IntegrityError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print("Invalid credentials ",err)
except pymysql.err.InterfaceError as err:
    print(err)
except Exception as err:
    print(err)
    print(sys.exc_info())

    
    
    
    
    