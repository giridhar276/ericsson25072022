# function
# Every process contains system calls (fork, exec, init..)

def add(a,b):
    c = a + b
    return c

total = add(10,20)   # 10 system calls
print(total)

total = add(10,200)   # 10 system calls
print(total)

total = add(10,220)   # 10 system calls
print(total)

total = add(110,20)   # 10 system calls
print(total)

total = add(130,20)   # 10 system calls
print(total)



# lambda function
# lambda function - inline function or anonymous function
# lambda is the single liner function
# Advantage: Istead of writing the function body.. lambda function is defined
# lambda expression values will be replaced in the calling function

#syntax
#functionname = lambda variables : expression
add = lambda x,y : x+y

total = add(10,20)   # 10 system calls
print(total)




square = lambda x : x*x if(x > 0) else None
print(square(6))





max = lambda a, b : a if(a > b) else b
 
print(max(1, 2))
print(max(10, 2))




test = lambda x : True if (x > 10 and x < 20) else False
# Check if given numbers are in range using lambda function
print(test(12))
print(test(3))
print(test(24))











