alist = [12,34,54,65,21,65]
print(alist)
# list.append(value)
alist.append(98)
print('After appending:',alist)
# list.extend([35,91,99])
alist.extend([35,91,99])
print('After extending:', alist)
# list.insert(index,value)
alist.insert(0,1000)
print('After inserting',alist)
# list.remove(value)
alist.remove(21)
print('After removing', alist)

if 21 in alist:
    alist.remove(21)
    print('After removing', alist)
else:
    print(21,"doesnt exist in the list")

# list.pop(index)   # if you know index value list.pop() can be used
alist.pop(0)
print('After pop', alist)
# reverse the values
alist.reverse()
print('After reversing', alist)
# sort the value - ascending order
alist.sort()
print('After sorting:', alist)
alist.sort(reverse = True)
print('After sorting:', alist)



# displaying list values one by one
alist = [99, 98, 91, 65, 65, 54, 35, 34, 12]
for val in alist:
    print(val)

name = "python"
for char in name:
    print(char)




















