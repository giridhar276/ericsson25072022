
# constructor will be invoked automatically when the object is created

# every class contains data members and member funtions(methods)
class Employee:
    # constructor
    def __init__(self,name,addr):
        # initializing values
        self.name = name
        self.addr = addr
    def displayAddress(self):
        print("Name   :", self.name)
        print("Address:", self.addr)


# object creation  or object initialization
emp1 = Employee('Ram','Hyd')
emp1.displayAddress()


emp2 = Employee('Rita','US')
emp2.displayAddress()


emp3 = Employee('Sita','Bang')
emp3.displayAddress()