import pymysql
import sys
import getpass       

try:
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='ericsson')
    
    cursor = conn.cursor()
    # step2
    query = "select * from realestate"
    #step3
    cursor.execute(query)
    #step4:
    for record in cursor.fetchall():
        print(record[0])
        print(record[1])
        print("----")
    conn.close()
except pymysql.err.IntegrityError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print("Invalid credentials ",err)
except pymysql.err.InterfaceError as err:
    print(err)
except Exception as err:
    print(err)
    print(sys.exc_info())

    
    
    
    
    