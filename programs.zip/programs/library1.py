
# importing all the methods
import math
print(math.log(2))
print(math.tan(1))
print(math.floor(34.2))

# importing with alias name
import math as m
print(m.log(2))
print(m.tan(1))
print(m.floor(34.2))


# import required methods ONLY
from math import log,tan,ceil
print(log(1))
print(tan(3))
print(ceil(1.3))