

atup=(45,43,45)
print(atup.count(45))