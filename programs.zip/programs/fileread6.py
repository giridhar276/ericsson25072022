

#
#Write a Python program to read realestate.csv and replace all the lines containing SACRAMENTO with BANGALORE and display the output on the screen      

with open("realestate.csv","r") as fobj:
    for line in fobj:
        line = line.replace('SACRAMENTO','BANGALORE')
        print(line)
        
        
        

with open("realestate.csv","r") as fobj:
    for line in fobj:
        if 'SACRAMENTO' in line:
            line = line.replace('SACRAMENTO','BANGALORE')
        print(line)        