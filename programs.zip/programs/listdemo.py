#LIST
alist = [10,20,30,1,34,89,32]
print(alist)
print(alist[0])
alist[0] = 100
print("list elements are ",alist)


# tuple - immutable ( unchangeable)
# Elements inside tuple can't be modified

atup = (12,23,34,21,4,6)
atup[0] = 1000
print("tuple elemnts are", atup)



atup = (12,23,34,21,4,6)
# converting to the list
alist= list(atup)
# make changes
alist.append(50)
# recoverting back to tuple
atup = tuple(alist)
print(atup)