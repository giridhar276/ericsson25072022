

# if any object if prefixed with * ... we call it as tuple
def display(*kargs):
    for val in kargs:
        print(val)




display(10,20,30,40,34,43,43,432,2,34,43,"unix","scala")






