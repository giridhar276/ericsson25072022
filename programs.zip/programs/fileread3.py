

            
with open("realestate.csv","r") as fobj:
    for line in fobj:
        output = line.split(",")
        print(output)
        if output[1] == 'SACRAMENTO':
            print(line.strip())    