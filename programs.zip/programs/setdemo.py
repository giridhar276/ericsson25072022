## set 
aset = {10,20,30,30,30}
bset = {30,30,30,40,40,40,50}

print(aset)
print(bset)

# set methods
# add new value to the set
aset.add(30)
print('After adding',aset)
aset.add(90)
print('After adding',aset)


# union operation
print(aset.union(bset))

# intersection
print(aset.intersection(bset))

# A-B
print(aset.difference(bset))