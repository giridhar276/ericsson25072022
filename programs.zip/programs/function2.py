# fixed arguments


def add(a,b):
    c = a + b
    return c



total = add(10,20)
print(total)