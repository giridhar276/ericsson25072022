

import requests
import json


# server
# endpoint
# payload

server = "https://api.github.com/"


response = requests.get(server)

if response.status_code == 200 :
    #print(response.text)
    # reponse becomes dictionary
    data = json.loads(response.text)
    for key,value in data.items():
        print(key.ljust(20), value)


