"""This package imitate Merchandises."""

from .category import categories
from .products import Merchandise

__all__ = ['Merchandise', 'categories']
